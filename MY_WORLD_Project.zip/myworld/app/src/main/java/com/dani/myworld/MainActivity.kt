package com.dani.myworld

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 20, 38)
    private val panel = Color.rgb(17, 35, 59)
    private val white = Color.rgb(238, 241, 242)
    private val muted = Color.rgb(164, 181, 202)
    private val accent = Color.rgb(204, 220, 237)
    private val prefs by lazy { getSharedPreferences("my_world_notes", MODE_PRIVATE) }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showWelcome()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(8,20,38), Color.rgb(15,35,61), Color.rgb(8,20,38)))
        }
    }

    private fun showWelcome() {
        root = base()
        root.gravity = Gravity.CENTER
        val moon = TextView(this).apply {
            text = "◯"
            textSize = 78f
            setTextColor(Color.rgb(226, 226, 211))
            gravity = Gravity.CENTER
        }
        root.addView(moon, LinearLayout.LayoutParams(-1, dp(130)))
        val title = TextView(this).apply {
            text = "MY WORLD"
            textSize = 30f
            letterSpacing = .20f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(54)))
        val tagline = TextView(this).apply {
            text = "Your life. Your ideas.\nYour own creation."
            textSize = 15f
            setLineSpacing(dp(5).toFloat(), 1f)
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(tagline, LinearLayout.LayoutParams(-1, dp(68)))
        val enter = button("ENTER MY WORLD") { showHome() }
        val p = LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0, dp(42), 0, 0)
        root.addView(enter, p)
        val footer = TextView(this).apply { text = "A little universe, made by you."; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER }
        val fp = LinearLayout.LayoutParams(-1, dp(38)); fp.setMargins(0, dp(26), 0, 0)
        root.addView(footer, fp)
        setContentView(root)
    }

    private fun showHome() {
        root = base()
        root.gravity = Gravity.TOP
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val eyebrow = text("YOUR PRIVATE UNIVERSE", 11f, muted).apply { letterSpacing = .16f }
        content.addView(eyebrow, matchWrap())
        val title = text("Welcome home.", 29f, white).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
        val tp = matchWrap(); tp.setMargins(0, dp(8), 0, dp(8)); content.addView(title, tp)
        content.addView(text("Small steps still move your world.", 14f, muted), matchWrap())
        addSection(content, "01", "MY LIFE", "Goals, plans, and the future you want to build.", "life")
        addSection(content, "02", "MY CREATION", "Sketches, app ideas, and things you make.", "creation")
        addSection(content, "03", "MY MIND", "A quiet place for thoughts you want to keep.", "mind")
        content.addView(text("Made for your own pace.", 12f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(54)))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun addSection(parent: LinearLayout, number: String, title: String, subtitle: String, key: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(17), dp(18), dp(16))
            background = rounded(panel, 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { showEditor(title, key, subtitle) }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(number, 12f, accent), LinearLayout.LayoutParams(dp(32), -2))
        row.addView(text(title, 17f, white).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); letterSpacing = .04f }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text("↗", 19f, muted))
        card.addView(row, matchWrap())
        val sub = text(subtitle, 13f, muted)
        val sp = matchWrap(); sp.setMargins(dp(32), dp(9), 0, 0); card.addView(sub, sp)
        val cp = LinearLayout.LayoutParams(-1, -2); cp.setMargins(0, dp(22), 0, 0); parent.addView(card, cp)
    }

    private fun showEditor(title: String, key: String, hint: String) {
        root = base()
        val back = button("←  MY WORLD") { showHome() }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(48)))
        val heading = text(title, 25f, white).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
        val hp = matchWrap(); hp.setMargins(0, dp(28), 0, dp(8)); root.addView(heading, hp)
        root.addView(text(hint, 13f, muted), matchWrap())
        val editor = EditText(this).apply {
            setText(prefs.getString(key, ""))
            setHint("Tulis sesuatu di sini...")
            setHintTextColor(Color.rgb(117, 137, 159))
            setTextColor(white)
            textSize = 16f
            gravity = Gravity.TOP or Gravity.START
            minLines = 8
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(panel, 14)
        }
        val ep = LinearLayout.LayoutParams(-1, 0, 1f); ep.setMargins(0, dp(24), 0, dp(20)); root.addView(editor, ep)
        root.addView(button("SAVE NOTE") {
            prefs.edit().putString(key, editor.text.toString()).apply()
            Toast.makeText(this, "Tersimpan di perangkat ini", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 13f; letterSpacing = .08f; setTextColor(bg); isAllCaps = false
        background = rounded(accent, 14); setOnClickListener { action() }
    }
    private fun text(value: String, size: Float, color: Int) = TextView(this).apply { text = value; textSize = size; setTextColor(color) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
